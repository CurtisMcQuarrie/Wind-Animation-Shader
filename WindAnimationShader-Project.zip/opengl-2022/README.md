# COMP 4490 - Final Project Implementation README

## Platform Details
**IDE**: Microsoft Visual Studio 2019.

**OS**: Windows 10 Pro version 21H1.

**Graphics hardware**: NVIDIA GeForce RTX 2060 SUPER.

## Running Program

My implementation is in the familiar OpenGL approach that we used for our assignments.

1. Open up the solution named ```mcquarrc-project.sln``` in Visual Studio 2019.
2. Build and Run the solution.

## Controls

My program has several controls to increase the interactivity of my implementation.
I will break down the controls based on the features that they affect.

### Scene Controls

These controls will affect the view and the geometry shown.

1. ```spacebar```
	- Change the geometry displayed.
2. ```left mouse button```
	- Rotate geometry around y-axis.
3. ```middle mouse button```
	- Rotate geometry around x-axis.
4. ```right mouse button```
	- Rotate geometry around z-axis.
5. ```q key``` or ```escape key```
	- Exit the program.
	
When changing the geometry displayed, there are 3 scenes created.

1. A scene with just the tree (the starting scene).
2. A scene with just the grass.
3. A scene with oth the trees and grass.

Pressing the ```space bar``` will cycle through these scenes.
	
### Wind Field Controls

These controls will affect the wind field for the geometry implementating the wind animation shader 
(```vShaderWindAnimation.glsl```).

1. ```w key```
	- Increase the wind strength along the Z-axis.
2. ```s key```
	- Decrease the wind strength along the Z-axis.
3. ```d key```
	- Increase the wind strength along the X-axis.
4. ```a key```
	- Decrease the wind strength along the X-axis.

### Wind Animation Controls

These controls will turn on and off features of the wind animation shader (```vShaderWindAnimation.glsl```). These include the main bending, detail bending, edge deformation, per-leaf bending, and per-leaf variation.

1. ```num 1 key```
	- Toggles the main bending feature in the wind animation shader.
	-  When the main bending feature is turned off, so is the detail bending.
2. ```num 2 key```
	- Toggles the detail bending feature in the wind animation shader.
	- When the detail bending feature is turned off, so is the ege deformation, per-leaf bending, and per-leaf variation.
3. ```num 3 key```
	- Toggles the edge deformation feature in the wind animation shader.
4. ```num 4 key```
	- Toggles the per-leaf bending feature in the wind animation shader.
5. ```num 5 key```
	- Toggles the per-leaf variation feature in the wind animation shader.

## Notes to Marker

When evaluating my implemetation, it is important to know that the vertex shader ```vShaderWindAnimation.glsl``` is the shader that applies the wind animation to the geometries.

In my implementation, I created 4 geometries:

	1. Tree trunk
	2. Tree leaves
	3. Grass
	4. Plane (the ground)

The wind animation shader (```vShaderWindAnimation.glsl```) is applied to the tree trunk, tree leaves, and grass geometries. The tree trunk and the grass geometries only ever have the main bending feature active and will not be affected by the detail bending feature. The tree leaves can have the main bending and detail bending features applied to it.

### External Sources
	
For all references that I used for my implementation, please see the "references" section in the report that is submitted with my project.

I think it is important to give extra acknowledgement that my implementation was based off the shader graphs found [here](https://minifloppy.it/tutorials/udk-wind-vertex-shader/). Absolutely no code was copied from this source because there is no code presented. The pattern of my code was however based off these shader graphs. Several modifications were done to the shader graph structure because of the differences in platform used and some strange behaviour I found during development. Please refer to the comments in my code for any major modifications.

## Author
**Name**: Curtis McQuarrie

**Student Number**: 7726150