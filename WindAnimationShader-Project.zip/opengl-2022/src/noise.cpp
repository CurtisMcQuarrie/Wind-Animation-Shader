// Generates 1/f Perlin Noise functions to use as the wind field in the main program.
// Utilizes two octaves.

#include <glm/glm.hpp>
#include "noise.h"
#include "time.h"


// matrix multipliers for cubic interpolated noise curve
glm::mat4 catmullRomLeft = {
     2.0, -3.0, 0.0, 1.0,
    -2.0,  3.0, 0.0, 0.0,
     1.0, -2.0, 1.0, 0.0,
     1.0, -1.0, 0.0, 0.0
};
glm::mat4 catmullRomRight = {
     0.0,  0.0, -0.5,  0.0,
     1.0,  0.0,  0.0, -0.5,
     0.0,  1.0,  0.5,  0.0,
     0.0,  0.0,  0.0,  0.5
};

//----------------------------------------------------------------------------

void printFloats(float floatBuffer[], int size)
{
    for (int loopCount = 0; loopCount < size; loopCount++)
    {
        printf("Index = %d\tValue = %f\n", loopCount, floatBuffer[loopCount]);
    }
}

//----------------------------------------------------------------------------

void printPoints(point4 pointsBuffer[], int size)
{
    for (int loopCount = 0; loopCount < size; loopCount++)
    {
        printf("Point = %d\tX = %f\tY = %f\t Z = %f\n", loopCount, pointsBuffer[loopCount].x, pointsBuffer[loopCount].y, pointsBuffer[loopCount].z);
    }
}
//----------------------------------------------------------------------------

void printIndices(GLuint indicesBuffer[], int size)
{
    for (int loopCount = 0; loopCount < size; loopCount += 3)
    {
        printf("Triangle = %d\tp1 = %d\tp2 = %d\tp3 = %d\n", loopCount / 3, indicesBuffer[loopCount], indicesBuffer[loopCount + 1], indicesBuffer[loopCount + 2]);
    }
}

//----------------------------------------------------------------------------
 
/*
* PURPOSE: Retrieves the maximum value in the provided float array.
* Always returns a positive value.
*/
float getMaxValue(float array[], int size)
{
    float maxValue = 0.0;

    for (int index = 0; index < size; index++)
    {
        float element = glm::abs(array[index]);
        // check for max
        if (element > maxValue)
        {
            maxValue = element;
        }
    }

    return maxValue;
}

//----------------------------------------------------------------------------

float* alterArray(const float arrayToAlter[], int size, float change, float minValue, float maxValue)
{
    float* returnArray = new float[size];
    for (int index = 0; index < size; index++)
    {
        returnArray[index] = glm::clamp(arrayToAlter[index] + change, minValue, maxValue);
    }
    return returnArray;
}

//----------------------------------------------------------------------------

float* zeroArray(int size)
{
    float* zeroArray = new float[size];
    for (int index = 0; index < size; index++)
    {
        zeroArray[index] = 0.0f;
    }
    return zeroArray;
}

//----------------------------------------------------------------------------

float* deepCopyArray(const float arrayToCopy[], int arraySize)
{
    float* copiedArray = new float[arraySize];
    for (int index = 0; index < arraySize; index++)
    {
        copiedArray[index] = arrayToCopy[index];
    }
    return copiedArray;
}

//----------------------------------------------------------------------------

float* invertArray(const float arrayToInvert[], int arraySize)
{
    float* invertedArray = new float[arraySize];
    for (int index = 0; index < arraySize; index++)
    {
        invertedArray[index] = -arrayToInvert[index];
    }
    return invertedArray;
}

//----------------------------------------------------------------------------

// as the name suggest, this will deep copy an array and scale its values in place
void scaleArray(float array[], const int arraySize, float scale)
{
    for (int loopCount = 0; loopCount < arraySize; loopCount++)
    {
        array[loopCount] = scale * array[loopCount];
    }
}

//----------------------------------------------------------------------------

// srcArray contains the randomly generated control points for the curve
void cubicInterpolate(float destArray[], int destSize, float srcArray[], int srcSize)
{
    // incrementing variables
    int pointCount = 0;
    float t = 0.0;
    int numPointsPerSeg = (int)destSize / srcSize; // where srcSize is the frequency of the curve
    float tInc = 1.0 / (float)numPointsPerSeg;
    // vectors for control points
    glm::vec4 cpPoints;
    // vectors for coefficient solution
    glm::vec4 coeff;
    // vector for interpolating wrt t
    glm::vec4 tVector;
    // indices for control points
    int index0, index1, index2, index3;

    // go through each curve segment of the line.
    for (int loopCount = 0; loopCount < srcSize; loopCount++)
    {
        // determine index values for control points
        index0 = loopCount;
        index1 = (loopCount + 1) % srcSize;
        index2 = (loopCount + 2) % srcSize;
        index3 = (loopCount + 3) % srcSize;
        // store the control points in vector4 variables
        cpPoints = { srcArray[index0], srcArray[index1], srcArray[index2], srcArray[index3] };
        // apply the catmull-rom matrix to solve for the coefficients
        coeff = catmullRomLeft * catmullRomRight * cpPoints;
        // reset the t value for new curve segment
        t = 0;
        // go through a single curve segment and place the cubic interpolated points inside the destArray
        for (int innerLoopCount = 0; innerLoopCount < numPointsPerSeg; innerLoopCount++)
        {
            // compute tVector
            tVector = { (float)glm::pow(t,3), (float)glm::pow(t,2), t, 1 };
            // store resulting dot product from tVector and coefficient solution for curve segment
            destArray[pointCount] = glm::dot(tVector, coeff);
            // increment counters
            pointCount++;
            t += tInc;
        }
    }
}

//----------------------------------------------------------------------------

void sumSimpleNoise1D(float destArray[], float* noiseArray1, float* noiseArray2, const int arraySizes)
{
    for (int loopCount = 0; loopCount < arraySizes; loopCount++)
    {
        destArray[loopCount] = noiseArray1[loopCount] + noiseArray2[loopCount];
    }
}

//----------------------------------------------------------------------------

// generate a single randomized noise array
float* generateSimpleNoise1D(const int arraySize, float amplitude)
{
    int randomInt;
    float randomFloat;
    float* noiseArray = new float[arraySize];
    srand(time(0));
    // loop through the size of the array and generate a random value between amplitude and -amplitude.
    for (int loopCount = 0; loopCount < arraySize; loopCount++)
    {
        randomInt = rand() % 101; // generate random in from 0 to 100
        randomFloat = randomInt / 100.0; // set range from 0 to 1
        noiseArray[loopCount] = randomFloat * amplitude; // scale the range to be from 0 to amplitude
    }

    return noiseArray;
}

//----------------------------------------------------------------------------

// pass in an array to store the 2 octave random noise curve
// enforces a 2:1 ratio for the frequencies to create an octave
// also enforce a 2:1 for the amplitudes.
void generateNoise(float noiseArray[], const int arraySize, float amplitude, const int freq)
{
    float freq2 = 2 * freq; // second noise wave should be double the frequency of the first
    float amplitude2 = amplitude / 2; // second noise wave should be half the amplitude of the first

    float* noiseCP1 = new float[freq];
    float* noiseCP2 = new float[freq2];

    float* noise1 = new float[arraySize];
    float* noise2 = new float[arraySize];

    // generate the control points
    noiseCP1 = generateSimpleNoise1D(freq, amplitude);
    noiseCP2 = generateSimpleNoise1D(freq2, amplitude2);

    // cubic interpolate between the control points
    cubicInterpolate(noise1, arraySize, noiseCP1, freq);
    cubicInterpolate(noise2, arraySize, noiseCP2, freq2);

    // sum the noise curves that should now octaves
    sumSimpleNoise1D(noiseArray, noise1, noise2, arraySize);
}