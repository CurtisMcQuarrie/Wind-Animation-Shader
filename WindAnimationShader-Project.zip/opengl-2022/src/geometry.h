#include "common.h"
#include<glm/glm.hpp>

// type declarations
typedef glm::vec4 point4;
typedef glm::vec3 vector3;

void drawQuad(GLuint[], int&, int, int, int, int);

void drawCylinderIndices(GLuint[]);

void drawLeafIndices(GLuint[]);

void drawGrassIndices(GLuint[]);

void drawCylinderPoints(point4[]);

void drawLeafPoints(point4 pointsBuffer[], vector3 normalBuffer[], vector3 colorBuffer[]);

void drawLeafPoints(point4[], vector3[], vector3[]);

void drawPlanePoints(point4[]);

void drawGrassPoints(point4[]);

void drawTrunk();

void drawLeaf();

void drawPlane();

void drawGrass();