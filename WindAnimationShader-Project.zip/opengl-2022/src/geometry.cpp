// Creates the geometry for the trunk and the leaves of the tree.

#include "geometry.h"
#include<glm/glm.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <time.h>

// math constants
const float PI = glm::pi<float>();

// trunk geometry constants
int numTrunkSegments = 8;
int numTrunkRings = 5;
int sizeTrunkPoints = numTrunkRings * numTrunkSegments;
int sizeTrunkIndices = 6 * (numTrunkRings - 1) * (numTrunkSegments);
float heightTrunk = 1.0;
float maxTrunkRadius = 0.15;
float minTrunkRadius = 0.0; //0.01;
// leaf geometry constants
float leafLength = 0.5;
float leafWidth = 0.1;
float leafHeightDec = 0.025;
int numLeafPlanesLength = 5;
int numLeafPlanesWidth = 3;
int numLeaves = 4; // max is 4
int sizeLeafPoints = numLeaves * (numLeafPlanesLength + 1) * (numLeafPlanesWidth + 1);
int sizeLeafIndices = 6 * numLeaves * numLeafPlanesLength * numLeafPlanesWidth;
// plane geometry
float planeSize = 2.0;
int sizePlanePoints = 4;
int sizePlaneIndices = 6;
// grass geometry
float grassPlaneSize = 0.15;
int numGrass = 12; // max is 12
int sizeGrassPoints = 8 * numGrass;
int sizeGrassIndices = 24 * numGrass;
// greater than 0.1 but less than 0.35
// no 2 positions should be within 0.01 of eachother
vector3 grassPositions[12] = { 
    vector3(-0.26, 0.0, -0.24),
    vector3(-0.1, 0.0, -0.25),
    vector3(-0.15, 0.0, -0.4),
    vector3(-0.31, 0.0, 0.02),
    vector3(-0.27, 0.0, 0.23),
    vector3(-0.21, 0.0, 0.15),
    vector3(0.12, 0.0, -0.26),
    vector3(0.22, 0.0, -0.15),
    vector3(0.36, 0.0, -0.25),
    vector3(0.30, 0.0, 0.23),
    vector3(0.05, 0.0, 0.31),
    vector3(0.26, 0.0, 0.1)
};

//--buffers--//
// trunk
point4* trunkPoints;
GLuint* trunkIndices;
// leaf
point4* leafPoints;
vector3* leafNormals;
vector3* leafColors;
GLuint* leafIndices;
// plane
point4* planePoints;
GLuint* planeIndices;
// grass
point4* grassPoints;
vector3* grassNormals;
vector3* grassColors;
GLuint* grassIndices;

//----------------------------------------------------------------------------

void drawQuad(GLuint indicesBuffer[], int& index, int a, int b, int c, int d)
{
    // triangle one
    indicesBuffer[index] = a;
    index++;
    indicesBuffer[index] = b;
    index++;
    indicesBuffer[index] = c;
    index++;
    // traingle two
    indicesBuffer[index] = b;
    index++;
    indicesBuffer[index] = c;
    index++;
    indicesBuffer[index] = d;
    index++;
}

//----------------------------------------------------------------------------

void drawCylinderIndices(GLuint indicesBuffer[])
{
    int indicesCount = 0;
    int pointsCount = 0;

    for (int ringCount = 0; ringCount < numTrunkRings - 1; ringCount++)
    {
        pointsCount = numTrunkSegments * ringCount;
        for (int segmentCount = 0; segmentCount < numTrunkSegments; segmentCount++)
        {
            if ((segmentCount % numTrunkSegments) == (numTrunkSegments - 1))
            {
                drawQuad(indicesBuffer, indicesCount, pointsCount, pointsCount - numTrunkSegments + 1, pointsCount + numTrunkSegments, pointsCount + 1);
            }
            else
            {
                drawQuad(indicesBuffer, indicesCount, pointsCount, pointsCount + 1, pointsCount + numTrunkSegments, pointsCount + numTrunkSegments + 1);
            }
            pointsCount++;
        }
    }
}

//----------------------------------------------------------------------------

void drawLeafIndices(GLuint indicesBuffer[])
{
    int indicesCount = 0;
    int pointsCount = 0;
    for (int leafCount = 0; leafCount < numLeaves; leafCount++)
    {
        pointsCount = leafCount * (numLeafPlanesLength + 1) * (numLeafPlanesWidth + 1);
        for (int outerCount = 0; outerCount < numLeafPlanesWidth; outerCount++)
        {
            for (int innerCount = 0; innerCount < numLeafPlanesLength; innerCount++)
            {
                drawQuad(indicesBuffer, indicesCount,
                    pointsCount, pointsCount + 1, pointsCount + (numLeafPlanesLength + 1), pointsCount + (numLeafPlanesLength + 2));
                pointsCount++;
            }
            pointsCount++;
        }
    }
}

//----------------------------------------------------------------------------

void drawGrassIndices(GLuint indicesBuffer[])
{
    int indexCount = 0;
    int pointsCount = 0;
    // each loop draws one pair grass planes
    for (int plane = 0; plane < numGrass; plane++)
    {
        pointsCount = plane * 8;
        drawQuad(indicesBuffer, indexCount, pointsCount, pointsCount + 1, pointsCount + 2, pointsCount + 3);
        pointsCount += 4;
        drawQuad(indicesBuffer, indexCount, pointsCount, pointsCount + 1, pointsCount + 2, pointsCount + 3);
    }
}

//----------------------------------------------------------------------------

void drawCylinderPoints(point4 pointsBuffer[])
{
    int pointsCount = 0;
    float t = 0.0;
    float height = 0.0;
    float radius = maxTrunkRadius;

    for (int ringCount = 0; ringCount < numTrunkRings; ringCount++)
    {
        for (int segmentCount = 0; segmentCount < numTrunkSegments; segmentCount++)
        {
            t = (float)segmentCount / (numTrunkSegments); // goes from 0 to 1
            pointsBuffer[pointsCount].x = radius * glm::cos(t * 2 * PI);
            pointsBuffer[pointsCount].y = height;
            pointsBuffer[pointsCount].z = radius * glm::sin(t * 2 * PI);
            pointsBuffer[pointsCount].w = 1.0;
            pointsCount++;
        }
        radius -= (maxTrunkRadius - minTrunkRadius) / numTrunkRings;
        height += (float)(heightTrunk / (numTrunkRings - 1.0));
    }
    assert(pointsCount == sizeTrunkPoints);
}

//----------------------------------------------------------------------------

void drawLeafPoints(point4 pointsBuffer[], vector3 normalBuffer[], vector3 colorBuffer[])
{
    int pointsIndex = 0;
    float x, y, z;
    float lengthInc; // 0 to length
    float widthInc; // -width/2 to width/2
    float widthDim, lengthDim;
    vector3 uVector, vVector;
    float greenChannel[] = {0.5, 0.1, 0.75, 0.32};

    for (int leafCount = 0; leafCount < numLeaves; leafCount++)
    {
        y = heightTrunk;
        lengthDim = 0.0;

        if (leafCount == 0)
        {
            widthDim = -leafWidth / 2.0;
            widthInc = leafWidth / (float)numLeafPlanesWidth;
            lengthInc = leafLength / (float)numLeafPlanesLength;
            uVector = { 0.0, 0.0, widthInc };
            vVector = { lengthInc, -leafHeightDec, 0.0 };
        }
        else if (leafCount == 1)
        {
            widthDim = -leafWidth / 2.0;
            widthInc = leafWidth / (float)numLeafPlanesWidth;
            lengthInc = leafLength / (float)numLeafPlanesLength;
            uVector = { 0.0, -leafHeightDec, lengthInc };
            vVector = { widthInc, 0.0, 0.0 };
        }
        else if (leafCount == 2)
        {
            widthDim = leafWidth / 2.0;
            widthInc = -leafWidth / (float)numLeafPlanesWidth;
            lengthInc = -leafLength / (float)numLeafPlanesLength;
            uVector = { 0.0, 0.0, widthInc };
            vVector = { lengthInc, -leafHeightDec, 0.0 };
        }
        else if (leafCount == 3)
        {
            widthDim = leafWidth / 2.0;
            widthInc = -leafWidth / (float)numLeafPlanesWidth;
            lengthInc = -leafLength / (float)numLeafPlanesLength;
            uVector = { 0.0, -leafHeightDec, lengthInc };
            vVector = { widthInc, 0.0, 0.0 };
        }

        for (int outerCount = 0; outerCount < numLeafPlanesWidth + 1; outerCount++)
        {
            for (int innerCount = 0; innerCount < numLeafPlanesLength + 1; innerCount++)
            {
                bool redChannelCheck = false;
                if (leafCount == 0)
                {
                    z = widthDim, x = lengthDim;
                    redChannelCheck = (widthDim < -leafWidth / 4 || widthDim > leafWidth / 4 || lengthDim == leafLength);
                }
                else if (leafCount == 1)
                {
                    x = widthDim, z = lengthDim;
                    redChannelCheck = (widthDim < -leafWidth / 4 || widthDim > leafWidth / 4 || lengthDim == leafLength);
                }
                else if (leafCount == 2)
                {
                    z = widthDim, x = lengthDim;
                    redChannelCheck = (widthDim < -leafWidth / 4 || widthDim > leafWidth / 4 || lengthDim == -leafLength);
                }
                else if (leafCount == 3)
                {
                    x = widthDim, z = lengthDim;
                    redChannelCheck = (widthDim < -leafWidth / 4 || widthDim > leafWidth / 4 || lengthDim == -leafLength);
                }

                pointsBuffer[pointsIndex] = { x, y, z, 1.0 };
                if (normalBuffer != NULL && colorBuffer != NULL)
                {
                    normalBuffer[pointsIndex] = glm::normalize(glm::cross(uVector, vVector)); // set vertex normals
                    // set vertex colours
                    colorBuffer[pointsIndex].g = greenChannel[leafCount];
                    if (redChannelCheck)
                    {
                        colorBuffer[pointsIndex].r = 1.0;
                    }
                    else
                    {
                        colorBuffer[pointsIndex].r = 0.0;
                    }
                    colorBuffer[pointsIndex].b = 1.0 - (glm::abs(lengthDim) / leafLength);
                }
                pointsIndex++;
                lengthDim += lengthInc;
                y -= leafHeightDec;
            }
            lengthDim = 0.0;
            y = heightTrunk;
            widthDim += widthInc;
        }
    }
}

//----------------------------------------------------------------------------

void drawGrassPoints(point4 pointsBuffer[], vector3 normalBuffer[], vector3 colorBuffer[])
{
    float x = 0.0, y = 0.0, z = 0.0;
    int pointsCount = 0;
    float delta = grassPlaneSize / 2.0;
    vector3 colorChannels;
    float greenChannel;
    vector3 xNormal = vector3(1.0, 0.0, 0.0); // planes are axes aligned
    vector3 zNormal = vector3(0.0, 0.0, 1.0); // planes are axes aligned
    srand(time(0));
    // loop through once for every pair of grass planes
    for (int grassCount = 0; grassCount < numGrass; grassCount++)
    {
        greenChannel = (rand() % 101) / 100.0; // get random green color
        colorChannels = vector3(0.0, greenChannel, 1.0); 
        x = grassPositions[grassCount].x;
        y = grassPositions[grassCount].y;
        z = grassPositions[grassCount].z;
        // first plane
        pointsBuffer[pointsCount] = { x + delta, y, z, 1.0 };
        normalBuffer[pointsCount] = zNormal; 
        colorBuffer[pointsCount] = colorChannels; 
        pointsCount++;
        pointsBuffer[pointsCount] = { x - delta, y, z, 1.0 };
        normalBuffer[pointsCount] = zNormal;
        colorBuffer[pointsCount] = colorChannels;
        pointsCount++;
        pointsBuffer[pointsCount] = { x + delta, y + grassPlaneSize, z, 1.0 };
        normalBuffer[pointsCount] = zNormal;
        colorChannels = vector3(0.0, greenChannel, 0.0);
        colorBuffer[pointsCount] = colorChannels;
        pointsCount++;
        pointsBuffer[pointsCount] = { x - delta, y + grassPlaneSize, z, 1.0 };
        normalBuffer[pointsCount] = zNormal;
        colorBuffer[pointsCount] = colorChannels;
        pointsCount++;
        // second plane
        colorChannels = vector3(0.0, greenChannel, 1.0);
        pointsBuffer[pointsCount] = { x, y, z + delta, 1.0 };
        normalBuffer[pointsCount] = xNormal;
        colorBuffer[pointsCount] = colorChannels;
        pointsCount++;
        pointsBuffer[pointsCount] = { x, y, z - delta, 1.0 };
        normalBuffer[pointsCount] = xNormal;
        colorBuffer[pointsCount] = colorChannels;
        pointsCount++;
        colorChannels = vector3(0.0, greenChannel, 0.0);
        pointsBuffer[pointsCount] = { x, y + grassPlaneSize, z + delta, 1.0 };
        normalBuffer[pointsCount] = xNormal;
        colorBuffer[pointsCount] = colorChannels;
        pointsCount++;
        pointsBuffer[pointsCount] = { x, y + grassPlaneSize, z - delta, 1.0 };
        normalBuffer[pointsCount] = xNormal;
        colorBuffer[pointsCount] = colorChannels;
        pointsCount++;
    }
}

//----------------------------------------------------------------------------

void drawPlanePoints(point4 pointsBuffer[])
{
    float size = planeSize / 2.0;
    pointsBuffer[0] = point4(size, 0.0, size, 1.0);
    pointsBuffer[1] = point4(-size, 0.0, size, 1.0);
    pointsBuffer[2] = point4(size, 0.0, -size, 1.0);
    pointsBuffer[3] = point4(-size, 0.0, -size, 1.0);
}

//----------------------------------------------------------------------------

void drawTrunk()
{
    trunkPoints = new point4[sizeTrunkPoints];
    trunkIndices = new GLuint[sizeTrunkIndices];
    drawCylinderPoints(trunkPoints);
    drawCylinderIndices(trunkIndices);
}

//----------------------------------------------------------------------------

void drawLeaf()
{
    leafPoints = new point4[sizeLeafPoints];
    leafNormals = new vector3[sizeLeafPoints];
    leafColors = new vector3[sizeLeafPoints];
    leafIndices = new GLuint[sizeLeafIndices];
    drawLeafPoints(leafPoints, leafNormals, leafColors);
    drawLeafIndices(leafIndices);
}

//----------------------------------------------------------------------------

void drawPlane()
{
    planePoints = new point4[sizePlanePoints];
    planeIndices = new GLuint[sizePlaneIndices];
    drawPlanePoints(planePoints);
    int indicesCount = 0;
    drawQuad(planeIndices, indicesCount, 0, 1, 2, 3);
}

//----------------------------------------------------------------------------

void drawGrass()
{
    grassPoints = new point4[sizeGrassPoints];
    grassNormals = new vector3[sizeGrassPoints];
    grassColors = new vector3[sizeGrassPoints];
    grassIndices = new GLuint[sizeGrassIndices];
    drawGrassPoints(grassPoints, grassNormals, grassColors);
    drawGrassIndices(grassIndices);
}