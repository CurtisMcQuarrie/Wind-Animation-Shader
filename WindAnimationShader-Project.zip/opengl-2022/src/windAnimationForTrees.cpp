// Draws the scene, generates the wind noise, and applies the vertex shader for wind animation onto the tree geometry.

#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include "windAnimationForTrees.h"

//--constants--//
// app constants
const char *WINDOW_TITLE = "Wind Animation for Trees";
const double FRAME_RATE_MS = 1000.0/60.0;
// camera constants
const glm::vec3 VIEWER_POS = { 0.0, 0.43, 2.75 };
const glm::vec3 CAMERA_ANGLE = { 15.0, 62.5, 0.0 };
const float NEAR_PLANE = 0.5;
const float FAR_PLANE = 4.5;
const float ROT_INCREMENT = 0.5f;
// noise constants
const int SIZE_NOISE = 120;
const int SPEED_NOISE_FREQ = 4; // make sure SIZE_NOISE is divisible by this value when changed
const int STRENGTH_NOISE_FREQ = 2; // make sure SIZE_NOISE is divisible by this value when changed
// interaction constants
const float AMP_INC = 0.1; // TODO: change

// wind values
point4 windDirectionAndSpeed = {1.0, 0.0, 1.0, 1.5}; // initiliazation
float currWindSpeedAmp = 1.0;
float currWindStrengthAmpX = 1.0;
float currWindStrengthAmpZ = 1.0;

//--wind--//
// wind interactivity
enum IsOn {MainBending, DetailBending, EdgeDeformation, PerLeafBending, PerLeafVariation, IsOnSize};
char* bendingTypes[] = { "MainBending", "DetailBending", "EdgeDeformation", "PerLeafBending", "PerLeafVariation" };
bool isOn[IsOnSize]; // handles what type of bending is on inside the wind animation vertex shader
float windSpeedMax = 0.0;
float windStrengthMaxX = 0.0;
float windStrengthMaxZ = 0.0;
float windSpeedInc = 0.0;
float windStrengthIncX = 0.0;
float windStrengthIncZ = 0.0;
// used to store current wind values when using interactivity
float* currWindSpeedNoise;
float* currWindStrengthNoiseX;
float* currWindStrengthNoiseZ;

// noise
float windSpeedNoise[SIZE_NOISE];
float windStrengthNoiseX[SIZE_NOISE];
float windStrengthNoiseZ[SIZE_NOISE];
int currentTimeIndex = 0;

// vaos
enum VAOType {Trunk, Leaf, Grass, Plane, VAOSize};
GLuint VAOs[VAOSize];

// geometry interactivity
int activeGeometry = Geometry::TreeGeometry;

// shader programs
GLuint programs[VAOSize];
GLuint ModelView[VAOSize];
GLuint Projection[VAOSize];

// wind uniforms
GLuint WindDirectionAndSpeed[VAOSize-1];
GLuint MainBendingSpeedScale[VAOSize-1];
GLuint MainBendingStrengthScale[VAOSize - 1];
GLuint EdgeDeformationSpeedScale[VAOSize - 1];
GLuint EdgeDeformationWaveSize[VAOSize - 1];
GLuint EdgeDeformationStrength[VAOSize - 1];
GLuint PerLeafBendingWaveSize[VAOSize - 1];
GLuint PerLeafBendingSpeedScale[VAOSize - 1];
GLuint PerLeafBendingStrength[VAOSize - 1];
GLuint VariationIntensity[VAOSize - 1];
GLuint MainBendingIsOn[VAOSize - 1];
GLuint DetailBendingIsOn[VAOSize - 1];
GLuint EdgeDeformationIsOn[VAOSize - 1];
GLuint PerLeafBendingIsOn[VAOSize - 1];
GLuint PerLeafVariationIsOn[VAOSize - 1];

// Array of rotation angles (in degrees) for each coordinate axis
enum { Xaxis = 0, Yaxis = 1, Zaxis = 2, NumAxes = 3 };
GLfloat  Theta[NumAxes] = { 0.0, 0.0, 0.0 }; // captures current rotation
GLfloat DeltaTheta[NumAxes] = { 0.0, 0.0, 0.0 }; // modifies rotation

//----------------------------------------------------------------------------

/*
* PURPOSE: To setup the vao and shader for a geometry that will NOT have the wind animation applied to it.
*/
void setupStaticBuffers(int vao, point4 pointsBuffer[], int pointsBufferSize, GLuint indicesBuffer[], int indicesBufferSize, char* vShader, char* fShader)
{
    // generate VAO
    glGenVertexArrays(1, &VAOs[Plane]);
    glBindVertexArray(VAOs[Plane]);

    GLuint buffer;

    // VBO
    glGenBuffers(1, &buffer);
    glBindBuffer(GL_ARRAY_BUFFER, buffer);
    glBufferData(GL_ARRAY_BUFFER, pointsBufferSize * sizeof(point4), pointsBuffer, GL_STATIC_DRAW);

    // Shader
    programs[vao] = InitShader(vShader, fShader);
    glUseProgram(programs[vao]);

    GLuint vPosition = glGetAttribLocation(programs[vao], "vPosition");
    glEnableVertexAttribArray(vPosition);
    glVertexAttribPointer(vPosition, 4, GL_FLOAT, GL_FALSE, 0, 0);

    // uniforms
    ModelView[vao] = glGetUniformLocation(programs[vao], "ModelView");
    Projection[vao] = glGetUniformLocation(programs[vao], "Projection");

    // IBO
    glGenBuffers(1, &buffer);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, buffer);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, indicesBufferSize * sizeof(GLuint), indicesBuffer, GL_STATIC_DRAW);
}

//----------------------------------------------------------------------------

/*
* PURPOSE: To setup the vao and shader for a geometry that will have the wind animation applied to it.
*/
void setupDynamicBuffers(int vao, point4 pointsBuffer[], int numVertices, vector3 normalBuffer[], vector3 colorBuffer[], GLuint indicesBuffer[], 
    int numIndices, char* fShader)
{
    // generate VAOs
    glGenVertexArrays(1, &VAOs[vao]);
    glBindVertexArray(VAOs[vao]);

    GLintptr offset = 0; // pointer to keep track of offset
    GLuint buffer;

    int point4Size = numVertices * sizeof(point4);
    int vec3Size = numVertices * sizeof(vector3);
    int bufferSize;
    if (normalBuffer == NULL || colorBuffer == NULL)
    {
        bufferSize = point4Size;
    }
    else
    {
        bufferSize = point4Size + (2 * vec3Size);
    }

    // VBO
    glGenBuffers(1, &buffer);
    glBindBuffer(GL_ARRAY_BUFFER, buffer);
    glBufferData(GL_ARRAY_BUFFER, bufferSize, NULL, GL_STATIC_DRAW);
    // vPosition
    glBufferSubData(GL_ARRAY_BUFFER, offset, point4Size, pointsBuffer);
    offset += point4Size;
    if (normalBuffer != NULL && colorBuffer != NULL)
    {
        // vNormal
        glBufferSubData(GL_ARRAY_BUFFER, offset, vec3Size, normalBuffer);
        offset += vec3Size;
        // vColor
        glBufferSubData(GL_ARRAY_BUFFER, offset, vec3Size, colorBuffer);
    }

    // Shader
    programs[vao] = InitShader("vShaderWindAnimation.glsl", fShader);
    glUseProgram(programs[vao]);

    // reset offset
    offset = 0;

    // vPosition
    GLuint vPosition = glGetAttribLocation(programs[vao], "vPosition");
    glEnableVertexAttribArray(vPosition);
    glVertexAttribPointer(vPosition, 4, GL_FLOAT, GL_FALSE, 0, BUFFER_OFFSET(offset));
    offset += point4Size;

    if (normalBuffer != NULL && colorBuffer != NULL)
    {
        // vNormal
        GLuint vNormal = glGetAttribLocation(programs[vao], "vNormal");
        glEnableVertexAttribArray(vNormal);
        glVertexAttribPointer(vNormal, 3, GL_FLOAT, GL_FALSE, 0, BUFFER_OFFSET(offset));
        offset += vec3Size;
        // vColor
        GLuint vColor = glGetAttribLocation(programs[vao], "vColor");
        glEnableVertexAttribArray(vColor);
        glVertexAttribPointer(vColor, 3, GL_FLOAT, GL_FALSE, 0, BUFFER_OFFSET(offset));
    }

    // uniforms
    ModelView[vao] = glGetUniformLocation(programs[vao], "ModelView");
    Projection[vao] = glGetUniformLocation(programs[vao], "Projection");
    WindDirectionAndSpeed[vao] = glGetUniformLocation(programs[vao], "WindDirectionAndSpeed");
    MainBendingStrengthScale[vao] = glGetUniformLocation(programs[vao], "MainBendingStrengthScale");
    MainBendingSpeedScale[vao] = glGetUniformLocation(programs[vao], "MainBendingSpeedScale");
    EdgeDeformationSpeedScale[vao] = glGetUniformLocation(programs[vao], "EdgeDeformationSpeedScale");
    EdgeDeformationWaveSize[vao] = glGetUniformLocation(programs[vao], "EdgeDeformationWaveSize");
    EdgeDeformationStrength[vao] = glGetUniformLocation(programs[vao], "EdgeDeformationStrength");
    PerLeafBendingWaveSize[vao] = glGetUniformLocation(programs[vao], "PerLeafBendingWaveSize");
    PerLeafBendingSpeedScale[vao] = glGetUniformLocation(programs[vao], "PerLeafBendingSpeedScale");
    PerLeafBendingStrength[vao] = glGetUniformLocation(programs[vao], "PerLeafBendingStrength");
    VariationIntensity[vao] = glGetUniformLocation(programs[vao], "VariationIntensity");
    MainBendingIsOn[vao] = glGetUniformLocation(programs[vao], "MainBendingIsOn");
    DetailBendingIsOn[vao] = glGetUniformLocation(programs[vao], "DetailBendingIsOn");
    EdgeDeformationIsOn[vao] = glGetUniformLocation(programs[vao], "EdgeDeformationIsOn");
    PerLeafBendingIsOn[vao] = glGetUniformLocation(programs[vao], "PerLeafBendingIsOn");
    PerLeafVariationIsOn[vao] = glGetUniformLocation(programs[vao], "PerLeafVariationIsOn");

    // IBO
    glGenBuffers(1, &buffer);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, buffer);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, numIndices * sizeof(GLuint), indicesBuffer, GL_STATIC_DRAW);
}


//----------------------------------------------------------------------------

/*
* PURPOSE: Provides interactivity with the direction of the wind.
* Does so by changing the values inside the noise function
*/
float* changeWindAmplitude(const float noise[], float &oldAmp, float change, float maxAmp)
{
    float newAmp = oldAmp + change;
    float* newNoise = new float[SIZE_NOISE];
    float minClamp = 0.0f, maxClamp = 0.0f;

    // case A: oldAmp is positive and change is positive
    if (oldAmp > 0 && change > 0)
    {
        minClamp = 0.0f;
        maxClamp = maxAmp;
        newNoise = deepCopyArray(noise, SIZE_NOISE);
    }
    // case B: oldAmp is negative and change is negative
    else if (oldAmp < 0 && change < 0)
    {
        minClamp = -maxAmp;
        maxClamp = 0.0f;
        newNoise = invertArray(noise, SIZE_NOISE);
    }
    else if (newAmp == 0)
    {
        newNoise = zeroArray(SIZE_NOISE);
    }
    // clamp min and max values
    else if (newAmp >= -maxAmp && newAmp <= maxAmp)
    {
        float delta = 0.0f;
        // case A: oldAmp is positive and change is negative
        if (oldAmp > 0 && change < 0)
        {
            minClamp = 0.0f;
            maxClamp = maxAmp;
            delta = change;
        }
        // case B: oldAmp is negative and change is positive
        else if (oldAmp < 0 && change > 0)
        {
            minClamp = -maxAmp;
            maxClamp = 0.0f;
            delta = -3 * change;
        }
        // case C: oldAmp is zero and change is positive
        else if (oldAmp == 0 && change > 0)
        {
            minClamp = 0.0f;
            maxClamp = maxAmp;
            delta = -change;
        }
        // case D: oldAmp is zero and change is negative
        else if (oldAmp == 0 && change < 0)
        {
            minClamp = -maxAmp;
            maxClamp = 0.0f;
            delta = 3 * change;
        }
        newNoise = alterArray(noise, SIZE_NOISE, delta, minClamp, maxClamp);
    }

    // determine new amp
    oldAmp = glm::clamp(oldAmp + change, minClamp, maxClamp);

    printIsOnStatus();
    printWindStatus();
    
    return newNoise;
}

//----------------------------------------------------------------------------

/*
* PURPOSE: Retrieve and set the components for the next wind value.
*/
void handleWindNoise()
{
        // modify the windDirectionAndSpeed based on noise
        windDirectionAndSpeed.x = currWindStrengthNoiseX[currentTimeIndex];
        windDirectionAndSpeed.z = currWindStrengthNoiseZ[currentTimeIndex];
        windDirectionAndSpeed.w = currWindSpeedNoise[currentTimeIndex];
        // increment the time index
        currentTimeIndex = ((currentTimeIndex + 1) % SIZE_NOISE);
}

//----------------------------------------------------------------------------

/*
* PURPOSE: Creates the noise functions for the X and Z wind strength components and also for the windSpeed.
*/
void generateWindNoise()
{
    // generate noise for main bending
    generateNoise(windSpeedNoise, SIZE_NOISE, currWindSpeedAmp, SPEED_NOISE_FREQ);
    generateNoise(windStrengthNoiseX, SIZE_NOISE, currWindStrengthAmpX, STRENGTH_NOISE_FREQ);
    generateNoise(windStrengthNoiseZ, SIZE_NOISE, currWindStrengthAmpZ, STRENGTH_NOISE_FREQ);
    // store the maximum values
    windSpeedMax = getMaxValue(windSpeedNoise, SIZE_NOISE);
    windStrengthMaxX = getMaxValue(windStrengthNoiseX, SIZE_NOISE);
    windStrengthMaxZ = getMaxValue(windStrengthNoiseZ, SIZE_NOISE);
    // calculate increment values for interactivity
    windSpeedInc = windSpeedMax / 2.0;
    windStrengthIncX = windStrengthMaxX / 2.0;
    windStrengthIncZ = windStrengthMaxZ / 2.0;
    // set current noise functions for interactivity
    currWindSpeedNoise = windSpeedNoise;
    currWindStrengthNoiseX = windStrengthNoiseX;
    currWindStrengthNoiseZ = windStrengthNoiseZ;
    currWindSpeedAmp = windSpeedMax;
    currWindStrengthAmpX = windStrengthMaxX;
    currWindStrengthAmpZ = windStrengthMaxZ;

    printWindStatus();
}

//----------------------------------------------------------------------------

/*
* PURPOSE: Initializes the values for the shader uniforms.
*/
void initShaderIsOnUniforms(int vao)
{
    glUseProgram(programs[vao]);
    glUniform1f(MainBendingSpeedScale[vao], 1.5);
    glUniform1i(MainBendingIsOn[vao], 0);
    glUniform1i(DetailBendingIsOn[vao], 0);
    glUniform1i(EdgeDeformationIsOn[vao], 0);
    // turn off detail bending for tree trunk and grass
    // also, turn off edge deformation
    /*if (vao == Trunk || vao == Grass)
    {
        glUniform1i(DetailBendingIsOn[vao], 0);
        glUniform1i(EdgeDeformationIsOn[vao], 0);
    }
    else
    {
        glUniform1i(DetailBendingIsOn[vao], 1);
        glUniform1i(EdgeDeformationIsOn[vao], 1);
    }*/
    glUniform1i(PerLeafBendingIsOn[vao], 0);
    glUniform1i(PerLeafVariationIsOn[vao], 0);
    glUniform1f(MainBendingStrengthScale[vao], 15.0);
    glUniform1f(EdgeDeformationSpeedScale[vao], 1.5);
    glUniform1f(EdgeDeformationWaveSize[vao], 1.0);
    glUniform1f(EdgeDeformationStrength[vao], 0.2);
    glUniform1f(PerLeafBendingWaveSize[vao], 1.0);
    glUniform1f(PerLeafBendingSpeedScale[vao], 1.0);
    glUniform1f(PerLeafBendingStrength[vao], 0.15);
    glUniform1f(VariationIntensity[vao], 1.0);
}

//----------------------------------------------------------------------------

void printWindStatus()
{
    printf("Wind Strength X Amplitude = %f\n", currWindStrengthAmpX);
    printf("Wind Strength Z Amplitude = %f\n", currWindStrengthAmpZ);
    printf("Wind Speed Amplitude = %f\n\n", currWindSpeedAmp);
}

//----------------------------------------------------------------------------

/*
* PURPOSE: Prints the isOn state for all bending types in the wind animation vertex shader.
*/
void printIsOnStatus() 
{
    char* bendingType = NULL;
    char* boolString = NULL;
    for (int type = 0; type < IsOnSize; type++)
    {
        bendingType = bendingTypes[type];
        boolString = isOn[type] ? "true" : "false";
        printf("%s = %s\n", bendingType, boolString);
    }
    printf("\n");
}

//----------------------------------------------------------------------------

/*
* PURPOSE: Toggles the isOn value of the specified type inside the wind animation shader for the appropriate geometries.
*/
void updateShaderIsOn(int type)
{
    isOn[type] = !isOn[type];
    // update all vaos to turn on/off main bending
    if (type == MainBending)
    {
        glUseProgram(programs[Trunk]);
        glUniform1i(MainBendingIsOn[Trunk], isOn[type]);
        glUseProgram(programs[Grass]);
        glUniform1i(MainBendingIsOn[Grass], isOn[type]);
        glUseProgram(programs[Leaf]);
        glUniform1i(MainBendingIsOn[Leaf], isOn[type]);
    }
    // update only vaos that need detail bending
    else if (type == DetailBending)
    {
        glUseProgram(programs[Leaf]);
        glUniform1i(DetailBendingIsOn[Leaf], isOn[type]);
        glUseProgram(programs[Grass]);
        glUniform1i(DetailBendingIsOn[Grass], isOn[type]);
    }
    // update only vaos that need edge deformation
    else if (type == EdgeDeformation)
    {
        glUseProgram(programs[Leaf]);
        glUniform1i(EdgeDeformationIsOn[Leaf], isOn[type]);
    }
    // update only vaos that need per-leaf bending
    else if (type == PerLeafBending)
    {
        glUseProgram(programs[Leaf]);
        glUniform1i(PerLeafBendingIsOn[Leaf], isOn[type]);
        glUseProgram(programs[Grass]);
        glUniform1i(DetailBendingIsOn[Grass], isOn[type]);
    }
    // update only vaos that need per-leaf variation
    else if (type == PerLeafVariation)
    {
        glUseProgram(programs[Leaf]);
        glUniform1i(PerLeafVariationIsOn[Leaf], isOn[type]);
        glUseProgram(programs[Grass]);
        glUniform1i(DetailBendingIsOn[Grass], isOn[type]);
    }

    printIsOnStatus();
}

//----------------------------------------------------------------------------

void drawGeometry()
{
    if (activeGeometry == Geometry::TreeGeometry)
    {
        // draw trunk
        glUseProgram(programs[Trunk]);
        glBindVertexArray(VAOs[Trunk]);
        glDrawElements(GL_TRIANGLES, sizeTrunkIndices, GL_UNSIGNED_INT, 0);
        // draw leaves
        glUseProgram(programs[Leaf]);
        glBindVertexArray(VAOs[Leaf]);
        glDrawElements(GL_TRIANGLES, sizeLeafIndices, GL_UNSIGNED_INT, 0);
    }
    else if (activeGeometry == Geometry::GrassGeometry)
    {
        // draw grass
        glUseProgram(programs[Grass]);
        glBindVertexArray(VAOs[Grass]);
        glDrawElements(GL_TRIANGLES, sizeGrassIndices, GL_UNSIGNED_INT, 0);
    }
    else if (activeGeometry == Geometry::BothGeometry)
    {
        // draw trunk
        glUseProgram(programs[Trunk]);
        glBindVertexArray(VAOs[Trunk]);
        glDrawElements(GL_TRIANGLES, sizeTrunkIndices, GL_UNSIGNED_INT, 0);
        // draw leaves
        glUseProgram(programs[Leaf]);
        glBindVertexArray(VAOs[Leaf]);
        glDrawElements(GL_TRIANGLES, sizeLeafIndices, GL_UNSIGNED_INT, 0);
        // draw grass
        glUseProgram(programs[Grass]);
        glBindVertexArray(VAOs[Grass]);
        glDrawElements(GL_TRIANGLES, sizeGrassIndices, GL_UNSIGNED_INT, 0);
    }
    // draw plane (ground)
    glUseProgram(programs[Plane]);
    glBindVertexArray(VAOs[Plane]);
    glDrawElements(GL_TRIANGLES, sizePlaneIndices, GL_UNSIGNED_INT, 0);
}

//----------------------------------------------------------------------------

// OpenGL initialization
void init()
{
    printIsOnStatus();
    // make the trunk
    drawTrunk();
    setupDynamicBuffers(Trunk, trunkPoints, sizeTrunkPoints, NULL, NULL, trunkIndices, sizeTrunkIndices, "fShaderTrunk.glsl");
    initShaderIsOnUniforms(Trunk);
    // make the leaves
    drawLeaf();
    setupDynamicBuffers(Leaf, leafPoints, sizeLeafPoints, leafNormals, leafColors, leafIndices, sizeLeafIndices, "fShaderLeaf.glsl");
    initShaderIsOnUniforms(Leaf);
    // make the grass
    drawGrass();
    setupDynamicBuffers(Grass, grassPoints, sizeGrassPoints, grassNormals, grassColors, grassIndices, sizeGrassIndices, "fShaderGrass.glsl");
    initShaderIsOnUniforms(Grass);
    // make the plane
    drawPlane();
    setupStaticBuffers(Plane, planePoints, sizePlanePoints, planeIndices, sizePlaneIndices, "vShaderStatic.glsl", "fShaderPlane.glsl");

    generateWindNoise();

    glEnable( GL_DEPTH_TEST );
    glClearColor(0.3633, 0.6602, 0.9102, 1.0);
}

//----------------------------------------------------------------------------

void
display( void )
{
   glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );

   //  Generate the model-view matrix
   glm::mat4 trans, rot, model_view;
   // translate camera for starting position
   trans = glm::translate(trans, -VIEWER_POS);
   // starting rotation for camera
   rot = glm::rotate(rot, glm::radians(CAMERA_ANGLE.x), glm::vec3(1, 0, 0));
   rot = glm::rotate(rot, glm::radians(CAMERA_ANGLE.y), glm::vec3(0, 1, 0));
   rot = glm::rotate(rot, glm::radians(CAMERA_ANGLE.z), glm::vec3(0, 0, 1));
   // rotate based on inputs
   rot = glm::rotate(rot, glm::radians(Theta[Xaxis]), glm::vec3(1, 0, 0));
   rot = glm::rotate(rot, glm::radians(Theta[Yaxis]), glm::vec3(0, 1, 0));
   rot = glm::rotate(rot, glm::radians(Theta[Zaxis]), glm::vec3(0, 0, 1));
   model_view = trans * rot;
   
   handleWindNoise();

   // draw the Trunk
   glUseProgram(programs[Trunk]);
   glUniformMatrix4fv( ModelView[Trunk], 1, GL_FALSE, glm::value_ptr(model_view) );
   glUniform4fv(WindDirectionAndSpeed[Trunk], 1, glm::value_ptr(windDirectionAndSpeed));

   // draw the leaf
   glUseProgram(programs[Leaf]);
   glUniformMatrix4fv(ModelView[Leaf], 1, GL_FALSE, glm::value_ptr(model_view));
   glUniform4fv(WindDirectionAndSpeed[Leaf], 1, glm::value_ptr(windDirectionAndSpeed));

   // draw the grass
   glUseProgram(programs[Grass]);
   glUniformMatrix4fv(ModelView[Grass], 1, GL_FALSE, glm::value_ptr(model_view));
   glUniform4fv(WindDirectionAndSpeed[Grass], 1, glm::value_ptr(windDirectionAndSpeed));

   // draw the plane
   glUseProgram(programs[Plane]);
   glUniformMatrix4fv(ModelView[Plane], 1, GL_FALSE, glm::value_ptr(model_view));

   drawGeometry();

   glutSwapBuffers();
}

//----------------------------------------------------------------------------

void
keyboard( unsigned char key, int x, int y )
{
    switch( key ) {
        case 033: // Escape Key
        case 'q': case 'Q':
            exit( EXIT_SUCCESS );
            break;
        case 'w': case 'W':
            currWindStrengthNoiseZ = changeWindAmplitude(windStrengthNoiseZ, currWindStrengthAmpZ, windStrengthIncZ, windStrengthMaxZ);
            break;
        case 's': case 'S':
            currWindStrengthNoiseZ = changeWindAmplitude(windStrengthNoiseZ, currWindStrengthAmpZ, -windStrengthIncZ, windStrengthMaxZ);
            break;
        case 'd': case 'D':
            currWindStrengthNoiseX = changeWindAmplitude(windStrengthNoiseX, currWindStrengthAmpX, windStrengthIncX, windStrengthMaxX);
            break;
        case 'a': case 'A':
            currWindStrengthNoiseX = changeWindAmplitude(windStrengthNoiseX, currWindStrengthAmpX, -windStrengthIncX, windStrengthMaxX);
            break;
        case 'z': case 'Z':
             currWindSpeedNoise = changeWindAmplitude(windSpeedNoise, currWindSpeedAmp, -windSpeedInc, windSpeedMax);
            break;
        case 'x': case 'X':
            currWindSpeedNoise = changeWindAmplitude(windSpeedNoise, currWindSpeedAmp, windSpeedInc, windSpeedMax);
            break;
        case 32: // Space Bar
            activeGeometry = ((activeGeometry + 1) % Geometry::Size);
            break;
        // toggle isOn uniforms in shader
        case 49: case 321: // 1 key on keyboard and num pad
            updateShaderIsOn(MainBending);
            break;
        case 50: case 322: // 2 key on keyboard and num pad
            updateShaderIsOn(DetailBending);
            break;
        case 51: case 323: // 3 key on keyboard and num pad
            updateShaderIsOn(EdgeDeformation);
            break;
        case 52: case 324: // 4 key on keyboard and num pad
            updateShaderIsOn(PerLeafBending);
            break;
        case 53: case 325: // 5 key on keyboard and num pad
            updateShaderIsOn(PerLeafVariation);
            break;
    }
}

//----------------------------------------------------------------------------

void
mouse( int button, int state, int x, int y )
{
    if (state == GLUT_DOWN) {
        switch (button) {
        case GLUT_LEFT_BUTTON:
            DeltaTheta[Yaxis] = (DeltaTheta[Yaxis] == ROT_INCREMENT) ? 0.0f : ROT_INCREMENT;
            break;
        case GLUT_MIDDLE_BUTTON:
            DeltaTheta[Xaxis] = (DeltaTheta[Xaxis] == ROT_INCREMENT) ? 0.0f : ROT_INCREMENT;
            break;
        case GLUT_RIGHT_BUTTON:
            DeltaTheta[Zaxis] = (DeltaTheta[Zaxis] == ROT_INCREMENT) ? 0.0f : ROT_INCREMENT;
            break;
        }
    }
}

//----------------------------------------------------------------------------

void
update( void )
{
    for (int axis = 0; axis < NumAxes; axis++)
    {
        Theta[axis] += DeltaTheta[axis];
        if (Theta[axis] > 360.0)
        {
            Theta[axis] -= 360.0;
        }
    }
}

//----------------------------------------------------------------------------

void
reshape( int width, int height )
{
   glViewport( 0, 0, width, height );

   GLfloat aspect = GLfloat(width)/height;
   glm::mat4  projection = glm::perspective( glm::radians(45.0f), aspect, NEAR_PLANE, FAR_PLANE );

   for (int vao = 0; vao < VAOSize; vao++)
   {
       glUseProgram(programs[vao]);
       glUniformMatrix4fv(Projection[vao], 1, GL_FALSE, glm::value_ptr(projection));
   }
}
