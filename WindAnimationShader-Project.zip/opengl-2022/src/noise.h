#include "geometry.h"

// utility
void printFloats(float[], int);

void printPoints(point4[], int);

void printIndices(GLuint[], int);

// array modifications
float* alterArray(const float[], int, float, float, float);

float* zeroArray(int);

float* deepCopyArray(const float[], int);

float* invertArray(const float[], int);

float getMaxValue(float[], int);

void scaleArray(float[], const int, float);

// actual noise creation
void cubicInterpolate(float[], int, float[], int);

void sumSimpleNoise1D(float[], float*, float*, const int);

float* generateSimpleNoise1D(const int, float);

void generateNoise(float[], const int, float, const int);