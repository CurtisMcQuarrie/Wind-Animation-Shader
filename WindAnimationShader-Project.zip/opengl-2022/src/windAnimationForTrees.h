#include "noise.h"

// type declarations
typedef glm::vec4 color4;
typedef glm::vec4 vector4;
typedef glm::mat4 matrix4;
typedef enum Geometry { TreeGeometry, GrassGeometry, BothGeometry, Size};

//--geometry--//
// trunk geometry
extern int numTrunkSegments;
extern int numTrunkRings;
extern int sizeTrunkPoints;
extern int sizeTrunkIndices;
extern float heightTrunk;
// leaf geometry
extern int numLeafPlanesX;
extern int numLeafPlanesZ;
extern int sizeLeafPoints;
extern int sizeLeafIndices;
extern int sizePlanePoints;
extern int sizePlaneIndices;
// grass geometry
extern float grassPlaneSize;
extern int numGrass;
extern int sizeGrassPoints;
extern int sizeGrassIndices;
extern vector3* grassPositions;
// buffers
extern point4* trunkPoints;
extern GLuint* trunkIndices;
extern point4* leafPoints;
extern vector3* leafNormals;
extern vector3* leafColors;
extern GLuint* leafIndices;
extern point4* planePoints;
extern GLuint* planeIndices;
extern point4* grassPoints;
extern vector3* grassNormals;
extern vector3* grassColors;
extern GLuint* grassIndices;

// vao setups
void initShaderIsOnUniforms(int);

void setupStaticBuffers(int, point4[], int, GLuint[], int, char*, char*);

void setupDynamicBuffers(int, point4[], int, vector3[], vector3[], GLuint[], int, char*);

// wind manipulation
void handleWindNoise();

void generateWindNoise();

//interactivity
float* changeWindAmplitude(const float[], float&, float, float);

void printWindStatus();

void printIsOnStatus();

void updateShaderIsOn(int);